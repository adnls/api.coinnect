pandas\.core\.resample\.Resampler\.get\_group
=============================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.get_group