pandas\.api\.types\.is\_unsigned\_integer\_dtype
================================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_unsigned_integer_dtype