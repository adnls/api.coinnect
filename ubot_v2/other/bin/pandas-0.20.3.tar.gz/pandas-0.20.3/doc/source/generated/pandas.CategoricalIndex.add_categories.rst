pandas\.CategoricalIndex\.add\_categories
=========================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.add_categories