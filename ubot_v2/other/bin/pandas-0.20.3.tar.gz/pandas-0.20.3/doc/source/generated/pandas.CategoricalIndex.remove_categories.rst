pandas\.CategoricalIndex\.remove\_categories
============================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.remove_categories