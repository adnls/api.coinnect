pandas\.DataFrame\.get
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.get