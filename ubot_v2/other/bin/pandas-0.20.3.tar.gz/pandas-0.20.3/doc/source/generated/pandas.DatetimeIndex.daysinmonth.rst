pandas\.DatetimeIndex\.daysinmonth
==================================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.daysinmonth