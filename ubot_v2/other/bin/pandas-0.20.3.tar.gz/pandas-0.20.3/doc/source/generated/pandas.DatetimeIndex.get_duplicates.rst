pandas\.DatetimeIndex\.get\_duplicates
======================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.get_duplicates