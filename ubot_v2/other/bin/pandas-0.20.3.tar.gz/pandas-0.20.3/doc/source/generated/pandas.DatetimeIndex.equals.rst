pandas\.DatetimeIndex\.equals
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.equals