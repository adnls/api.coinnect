pandas\.core\.resample\.Resampler\.sem
======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.sem