pandas\.DatetimeIndex\.asobject
===============================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.asobject