pandas\.DataFrame\.describe
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.describe