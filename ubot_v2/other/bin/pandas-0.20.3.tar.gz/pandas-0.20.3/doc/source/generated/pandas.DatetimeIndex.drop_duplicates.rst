pandas\.DatetimeIndex\.drop\_duplicates
=======================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.drop_duplicates