pandas\.api\.types\.is\_dict\_like
==================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_dict_like