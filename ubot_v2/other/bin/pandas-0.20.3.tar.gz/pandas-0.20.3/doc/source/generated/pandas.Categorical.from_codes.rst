pandas\.Categorical\.from\_codes
================================

.. currentmodule:: pandas

.. automethod:: Categorical.from_codes