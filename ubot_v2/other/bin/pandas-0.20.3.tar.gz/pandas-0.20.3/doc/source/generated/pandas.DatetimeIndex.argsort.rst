pandas\.DatetimeIndex\.argsort
==============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.argsort