pandas\.DataFrame\.pivot
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.pivot