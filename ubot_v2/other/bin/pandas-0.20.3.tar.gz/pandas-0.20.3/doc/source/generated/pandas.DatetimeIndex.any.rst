pandas\.DatetimeIndex\.any
==========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.any