pandas\.DataFrame\.to\_records
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_records