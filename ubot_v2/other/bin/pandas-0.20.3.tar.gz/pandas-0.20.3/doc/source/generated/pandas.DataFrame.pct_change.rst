pandas\.DataFrame\.pct\_change
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.pct_change