pandas\.core\.resample\.Resampler\.ohlc
=======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.ohlc