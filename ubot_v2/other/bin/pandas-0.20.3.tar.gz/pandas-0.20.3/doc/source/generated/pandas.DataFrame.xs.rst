pandas\.DataFrame\.xs
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.xs