pandas\.core\.window\.Expanding\.cov
====================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.cov