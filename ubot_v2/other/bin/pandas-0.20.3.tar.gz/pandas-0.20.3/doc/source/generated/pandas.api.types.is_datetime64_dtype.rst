pandas\.api\.types\.is\_datetime64\_dtype
=========================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_datetime64_dtype