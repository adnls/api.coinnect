pandas\.date\_range
===================

.. currentmodule:: pandas

.. autofunction:: date_range