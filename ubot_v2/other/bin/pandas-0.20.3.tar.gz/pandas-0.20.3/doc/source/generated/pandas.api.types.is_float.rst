pandas\.api\.types\.is\_float
=============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_float