pandas\.api\.types\.is\_datetime64tz\_dtype
===========================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_datetime64tz_dtype