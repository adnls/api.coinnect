pandas\.api\.types\.is\_re\_compilable
======================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_re_compilable