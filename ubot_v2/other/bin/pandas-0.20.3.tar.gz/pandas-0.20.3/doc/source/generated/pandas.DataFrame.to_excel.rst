pandas\.DataFrame\.to\_excel
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_excel