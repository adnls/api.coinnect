pandas\.DatetimeIndex\.append
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.append