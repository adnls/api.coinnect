pandas\.DataFrame\.from\_dict
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_dict