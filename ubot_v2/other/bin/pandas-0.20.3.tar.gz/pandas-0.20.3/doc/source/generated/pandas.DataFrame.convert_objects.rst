pandas\.DataFrame\.convert\_objects
===================================

.. currentmodule:: pandas

.. automethod:: DataFrame.convert_objects