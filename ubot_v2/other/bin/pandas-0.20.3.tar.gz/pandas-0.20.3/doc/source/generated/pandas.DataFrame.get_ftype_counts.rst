pandas\.DataFrame\.get\_ftype\_counts
=====================================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_ftype_counts