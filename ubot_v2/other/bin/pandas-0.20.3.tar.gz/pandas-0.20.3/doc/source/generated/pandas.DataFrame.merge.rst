pandas\.DataFrame\.merge
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.merge