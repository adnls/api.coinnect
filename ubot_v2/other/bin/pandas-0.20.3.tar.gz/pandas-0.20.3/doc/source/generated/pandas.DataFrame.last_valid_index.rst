pandas\.DataFrame\.last\_valid\_index
=====================================

.. currentmodule:: pandas

.. automethod:: DataFrame.last_valid_index