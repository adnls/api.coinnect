pandas\.core\.resample\.Resampler\.var
======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.var