pandas\.DataFrame\.ix
=====================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.ix