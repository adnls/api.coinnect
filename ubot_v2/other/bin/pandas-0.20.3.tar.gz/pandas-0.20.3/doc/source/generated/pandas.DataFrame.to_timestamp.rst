pandas\.DataFrame\.to\_timestamp
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_timestamp