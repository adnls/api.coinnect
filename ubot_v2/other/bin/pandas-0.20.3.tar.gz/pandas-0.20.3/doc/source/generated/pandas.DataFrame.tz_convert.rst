pandas\.DataFrame\.tz\_convert
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.tz_convert