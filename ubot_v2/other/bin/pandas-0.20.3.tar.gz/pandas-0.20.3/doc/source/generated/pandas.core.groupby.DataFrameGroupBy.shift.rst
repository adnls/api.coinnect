pandas\.core\.groupby\.DataFrameGroupBy\.shift
==============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.shift