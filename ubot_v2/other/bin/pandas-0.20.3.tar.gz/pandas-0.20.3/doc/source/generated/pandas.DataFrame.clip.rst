pandas\.DataFrame\.clip
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.clip