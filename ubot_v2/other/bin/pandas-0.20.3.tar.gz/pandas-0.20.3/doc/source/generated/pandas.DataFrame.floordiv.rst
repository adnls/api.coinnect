pandas\.DataFrame\.floordiv
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.floordiv