pandas\.DataFrame\.sum
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.sum