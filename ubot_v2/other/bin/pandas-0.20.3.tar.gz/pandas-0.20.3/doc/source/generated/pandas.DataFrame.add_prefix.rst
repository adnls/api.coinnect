pandas\.DataFrame\.add\_prefix
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.add_prefix