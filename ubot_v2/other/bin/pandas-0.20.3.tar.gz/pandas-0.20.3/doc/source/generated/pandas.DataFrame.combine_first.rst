pandas\.DataFrame\.combine\_first
=================================

.. currentmodule:: pandas

.. automethod:: DataFrame.combine_first