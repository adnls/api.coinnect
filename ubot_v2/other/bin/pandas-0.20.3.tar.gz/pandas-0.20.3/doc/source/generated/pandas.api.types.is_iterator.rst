pandas\.api\.types\.is\_iterator
================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_iterator