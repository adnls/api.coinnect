pandas\.DatetimeIndex\.contains
===============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.contains