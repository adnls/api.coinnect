pandas\.DataFrame\.values
=========================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.values