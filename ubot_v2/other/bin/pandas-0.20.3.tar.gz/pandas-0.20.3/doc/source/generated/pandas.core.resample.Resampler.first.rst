pandas\.core\.resample\.Resampler\.first
========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.first