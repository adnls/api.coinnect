pandas\.api\.types\.is\_categorical
===================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_categorical