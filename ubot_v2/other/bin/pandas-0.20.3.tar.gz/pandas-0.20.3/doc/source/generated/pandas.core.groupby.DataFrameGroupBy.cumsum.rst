pandas\.core\.groupby\.DataFrameGroupBy\.cumsum
===============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.cumsum