pandas\.core\.groupby\.GroupBy\.get\_group
==========================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.get_group