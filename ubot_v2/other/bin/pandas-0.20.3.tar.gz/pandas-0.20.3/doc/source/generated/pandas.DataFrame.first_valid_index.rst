pandas\.DataFrame\.first\_valid\_index
======================================

.. currentmodule:: pandas

.. automethod:: DataFrame.first_valid_index