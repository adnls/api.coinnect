pandas\.DatetimeIndex\.days\_in\_month
======================================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.days_in_month