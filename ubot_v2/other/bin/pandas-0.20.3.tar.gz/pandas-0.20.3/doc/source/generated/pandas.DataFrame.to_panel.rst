pandas\.DataFrame\.to\_panel
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_panel