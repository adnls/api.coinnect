pandas\.DataFrame\.assign
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.assign