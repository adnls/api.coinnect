pandas\.DataFrame\.agg
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.agg