pandas\.DatetimeIndex\.asof
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.asof