pandas\.DataFrame\.to\_msgpack
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_msgpack