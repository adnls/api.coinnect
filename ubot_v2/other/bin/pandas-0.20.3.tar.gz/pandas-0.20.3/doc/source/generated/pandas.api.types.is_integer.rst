pandas\.api\.types\.is\_integer
===============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_integer