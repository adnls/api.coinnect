pandas\.DataFrame\.asof
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.asof