pandas\.core\.groupby\.DataFrameGroupBy\.any
============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.any