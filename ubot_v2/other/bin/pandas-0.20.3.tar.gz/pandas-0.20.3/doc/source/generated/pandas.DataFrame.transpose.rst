pandas\.DataFrame\.transpose
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.transpose