pandas\.core\.resample\.Resampler\.interpolate
==============================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.interpolate