pandas\.DataFrame\.mode
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.mode