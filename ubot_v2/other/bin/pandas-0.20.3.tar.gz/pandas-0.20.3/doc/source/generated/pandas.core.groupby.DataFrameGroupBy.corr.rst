pandas\.core\.groupby\.DataFrameGroupBy\.corr
=============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.corr