pandas\.DataFrame\.rdiv
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.rdiv