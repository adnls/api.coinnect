pandas\.CategoricalIndex\.reorder\_categories
=============================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.reorder_categories