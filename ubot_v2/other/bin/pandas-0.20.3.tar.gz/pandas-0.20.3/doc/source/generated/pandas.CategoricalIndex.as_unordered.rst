pandas\.CategoricalIndex\.as\_unordered
=======================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.as_unordered