pandas\.Categorical\.\_\_array\_\_
==================================

.. currentmodule:: pandas

.. automethod:: Categorical.__array__