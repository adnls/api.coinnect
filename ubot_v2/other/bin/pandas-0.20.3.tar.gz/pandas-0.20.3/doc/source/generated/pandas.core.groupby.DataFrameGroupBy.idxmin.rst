pandas\.core\.groupby\.DataFrameGroupBy\.idxmin
===============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.idxmin