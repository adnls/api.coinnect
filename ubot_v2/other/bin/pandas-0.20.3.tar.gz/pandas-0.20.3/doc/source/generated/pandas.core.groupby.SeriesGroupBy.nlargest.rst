pandas\.core\.groupby\.SeriesGroupBy\.nlargest
==============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: SeriesGroupBy.nlargest