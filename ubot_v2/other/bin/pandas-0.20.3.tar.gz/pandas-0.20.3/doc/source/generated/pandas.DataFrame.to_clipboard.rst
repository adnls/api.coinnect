pandas\.DataFrame\.to\_clipboard
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_clipboard