pandas\.DataFrame\.slice\_shift
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.slice_shift