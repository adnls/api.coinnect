pandas\.core\.window\.Expanding\.skew
=====================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.skew