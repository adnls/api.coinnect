pandas\.DataFrame\.rmod
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.rmod