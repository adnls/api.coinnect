pandas\.api\.types\.pandas\_dtype
=================================

.. currentmodule:: pandas.api.types

.. autofunction:: pandas_dtype