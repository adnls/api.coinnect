pandas\.DataFrame\.notnull
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.notnull