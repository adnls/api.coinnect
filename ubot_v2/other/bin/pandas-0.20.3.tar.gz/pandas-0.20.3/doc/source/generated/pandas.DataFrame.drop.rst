pandas\.DataFrame\.drop
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.drop