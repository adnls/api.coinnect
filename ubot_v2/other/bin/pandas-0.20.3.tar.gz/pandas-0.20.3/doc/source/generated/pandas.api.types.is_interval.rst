pandas\.api\.types\.is\_interval
================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_interval