pandas\.DataFrame\.to\_xarray
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_xarray