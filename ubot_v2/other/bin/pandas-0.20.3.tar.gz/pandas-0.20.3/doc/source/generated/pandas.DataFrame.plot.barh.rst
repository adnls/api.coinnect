pandas.DataFrame.plot.barh
==========================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.barh