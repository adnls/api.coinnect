pandas\.DataFrame\.append
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.append