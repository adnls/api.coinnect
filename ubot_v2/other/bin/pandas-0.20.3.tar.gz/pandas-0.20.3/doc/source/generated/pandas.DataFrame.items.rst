pandas\.DataFrame\.items
========================

.. currentmodule:: pandas

.. automethod:: DataFrame.items