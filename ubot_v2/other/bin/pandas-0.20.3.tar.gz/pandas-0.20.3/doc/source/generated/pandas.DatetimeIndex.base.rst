pandas\.DatetimeIndex\.base
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.base