pandas\.api\.types\.infer\_dtype
================================

.. currentmodule:: pandas.api.types

.. autofunction:: infer_dtype