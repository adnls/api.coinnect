pandas\.api\.types\.is\_bool\_dtype
===================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_bool_dtype