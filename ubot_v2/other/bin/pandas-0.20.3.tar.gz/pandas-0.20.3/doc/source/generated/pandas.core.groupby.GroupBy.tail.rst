pandas\.core\.groupby\.GroupBy\.tail
====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.tail