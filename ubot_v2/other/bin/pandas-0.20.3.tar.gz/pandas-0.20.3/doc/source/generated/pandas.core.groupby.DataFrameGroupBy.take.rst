pandas\.core\.groupby\.DataFrameGroupBy\.take
=============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.take