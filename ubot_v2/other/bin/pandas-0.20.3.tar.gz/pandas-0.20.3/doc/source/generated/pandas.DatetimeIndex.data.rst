pandas\.DatetimeIndex\.data
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.data