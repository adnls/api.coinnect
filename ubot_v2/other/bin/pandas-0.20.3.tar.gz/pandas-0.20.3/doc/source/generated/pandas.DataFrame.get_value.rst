pandas\.DataFrame\.get\_value
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_value