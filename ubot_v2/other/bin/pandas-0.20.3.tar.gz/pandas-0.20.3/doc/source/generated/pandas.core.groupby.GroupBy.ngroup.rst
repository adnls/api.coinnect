pandas\.core\.groupby\.GroupBy\.ngroup
======================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.ngroup