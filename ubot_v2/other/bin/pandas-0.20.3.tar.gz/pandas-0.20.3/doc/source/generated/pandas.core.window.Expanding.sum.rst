pandas\.core\.window\.Expanding\.sum
====================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.sum