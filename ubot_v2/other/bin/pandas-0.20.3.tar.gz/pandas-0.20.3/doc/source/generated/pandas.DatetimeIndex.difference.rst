pandas\.DatetimeIndex\.difference
=================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.difference