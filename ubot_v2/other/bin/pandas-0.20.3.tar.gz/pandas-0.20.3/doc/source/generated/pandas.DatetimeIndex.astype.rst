pandas\.DatetimeIndex\.astype
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.astype