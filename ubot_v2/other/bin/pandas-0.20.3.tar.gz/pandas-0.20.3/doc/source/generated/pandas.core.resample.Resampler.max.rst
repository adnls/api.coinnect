pandas\.core\.resample\.Resampler\.max
======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.max