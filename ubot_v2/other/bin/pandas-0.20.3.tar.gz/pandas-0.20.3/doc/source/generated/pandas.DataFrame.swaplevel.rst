pandas\.DataFrame\.swaplevel
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.swaplevel