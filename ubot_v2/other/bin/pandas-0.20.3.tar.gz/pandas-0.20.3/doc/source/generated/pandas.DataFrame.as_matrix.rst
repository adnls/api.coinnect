pandas\.DataFrame\.as\_matrix
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.as_matrix