pandas\.DataFrame\.replace
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.replace