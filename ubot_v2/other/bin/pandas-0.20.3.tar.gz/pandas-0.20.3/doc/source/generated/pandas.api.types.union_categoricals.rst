pandas\.api\.types\.union\_categoricals
=======================================

.. currentmodule:: pandas.api.types

.. autofunction:: union_categoricals