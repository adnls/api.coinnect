pandas\.core\.resample\.Resampler\.apply
========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.apply