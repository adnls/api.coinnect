pandas\.DatetimeIndex\.dayofyear
================================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.dayofyear