pandas\.DataFrame\.cumprod
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.cumprod