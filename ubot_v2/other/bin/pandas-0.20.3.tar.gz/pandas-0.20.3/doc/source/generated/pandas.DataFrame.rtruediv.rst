pandas\.DataFrame\.rtruediv
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.rtruediv