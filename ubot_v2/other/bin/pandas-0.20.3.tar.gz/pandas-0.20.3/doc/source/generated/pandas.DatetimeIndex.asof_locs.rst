pandas\.DatetimeIndex\.asof\_locs
=================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.asof_locs