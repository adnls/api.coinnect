pandas\.core\.window\.Window\.sum
=================================

.. currentmodule:: pandas.core.window

.. automethod:: Window.sum