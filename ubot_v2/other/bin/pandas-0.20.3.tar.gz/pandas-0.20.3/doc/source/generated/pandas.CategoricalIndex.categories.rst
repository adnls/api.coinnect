pandas\.CategoricalIndex\.categories
====================================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.categories