pandas\.DatetimeIndex\.empty
============================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.empty