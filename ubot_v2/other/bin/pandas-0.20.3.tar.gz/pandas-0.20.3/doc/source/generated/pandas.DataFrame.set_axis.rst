pandas\.DataFrame\.set\_axis
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.set_axis