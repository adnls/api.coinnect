pandas\.DataFrame\.from\_records
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_records