pandas\.DataFrame\.memory\_usage
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.memory_usage