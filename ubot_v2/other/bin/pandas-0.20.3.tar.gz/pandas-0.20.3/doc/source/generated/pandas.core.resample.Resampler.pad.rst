pandas\.core\.resample\.Resampler\.pad
======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.pad