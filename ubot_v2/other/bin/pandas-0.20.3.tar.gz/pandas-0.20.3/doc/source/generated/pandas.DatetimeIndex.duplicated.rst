pandas\.DatetimeIndex\.duplicated
=================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.duplicated