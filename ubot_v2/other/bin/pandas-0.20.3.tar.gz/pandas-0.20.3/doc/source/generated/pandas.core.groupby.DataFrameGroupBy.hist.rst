pandas\.core\.groupby\.DataFrameGroupBy\.hist
=============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.hist