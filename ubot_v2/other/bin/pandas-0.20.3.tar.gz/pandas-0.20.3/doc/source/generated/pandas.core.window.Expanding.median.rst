pandas\.core\.window\.Expanding\.median
=======================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.median