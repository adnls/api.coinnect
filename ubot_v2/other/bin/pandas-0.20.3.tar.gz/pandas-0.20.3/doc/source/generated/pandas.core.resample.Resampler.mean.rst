pandas\.core\.resample\.Resampler\.mean
=======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.mean