pandas\.core\.groupby\.GroupBy\.nth
===================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.nth