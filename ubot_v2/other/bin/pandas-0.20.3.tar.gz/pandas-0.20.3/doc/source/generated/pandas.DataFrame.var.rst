pandas\.DataFrame\.var
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.var