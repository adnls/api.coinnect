pandas\.DataFrame\.diff
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.diff