pandas\.DatetimeIndex\.dayofweek
================================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.dayofweek