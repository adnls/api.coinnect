pandas\.DataFrame\.expanding
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.expanding