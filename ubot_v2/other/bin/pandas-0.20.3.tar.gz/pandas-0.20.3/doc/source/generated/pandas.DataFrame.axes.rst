pandas\.DataFrame\.axes
=======================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.axes