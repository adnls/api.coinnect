pandas\.api\.types\.is\_numeric\_dtype
======================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_numeric_dtype