pandas\.api\.types\.is\_datetime64\_any\_dtype
==============================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_datetime64_any_dtype