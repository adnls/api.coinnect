pandas\.core\.resample\.Resampler\.std
======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.std