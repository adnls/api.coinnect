pandas\.DataFrame\.to\_stata
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_stata