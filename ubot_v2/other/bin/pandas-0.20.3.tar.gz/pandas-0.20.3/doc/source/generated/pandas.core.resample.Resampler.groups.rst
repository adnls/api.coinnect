pandas\.core\.resample\.Resampler\.groups
=========================================

.. currentmodule:: pandas.core.resample

.. autoattribute:: Resampler.groups