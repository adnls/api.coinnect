pandas\.DataFrame\.\_\_iter\_\_
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.__iter__