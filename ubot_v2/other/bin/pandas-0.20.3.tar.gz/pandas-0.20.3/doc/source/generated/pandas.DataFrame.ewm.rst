pandas\.DataFrame\.ewm
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.ewm