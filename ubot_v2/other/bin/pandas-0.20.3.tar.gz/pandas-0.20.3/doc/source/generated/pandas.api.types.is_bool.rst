pandas\.api\.types\.is\_bool
============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_bool