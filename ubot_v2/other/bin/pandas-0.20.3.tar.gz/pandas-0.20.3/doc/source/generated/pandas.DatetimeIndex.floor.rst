pandas\.DatetimeIndex\.floor
============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.floor