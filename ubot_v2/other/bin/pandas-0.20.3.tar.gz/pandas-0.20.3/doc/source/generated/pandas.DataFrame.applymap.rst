pandas\.DataFrame\.applymap
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.applymap