pandas\.DataFrame\.clip\_upper
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.clip_upper