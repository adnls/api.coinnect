pandas\.DataFrame\.to\_sparse
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_sparse