pandas\.CategoricalIndex\.codes
===============================

.. currentmodule:: pandas

.. autoattribute:: CategoricalIndex.codes