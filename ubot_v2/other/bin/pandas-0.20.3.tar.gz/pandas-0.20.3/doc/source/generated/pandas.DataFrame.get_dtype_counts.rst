pandas\.DataFrame\.get\_dtype\_counts
=====================================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_dtype_counts