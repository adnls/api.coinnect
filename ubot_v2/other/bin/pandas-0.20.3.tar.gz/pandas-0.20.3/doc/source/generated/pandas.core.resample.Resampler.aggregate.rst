pandas\.core\.resample\.Resampler\.aggregate
============================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.aggregate