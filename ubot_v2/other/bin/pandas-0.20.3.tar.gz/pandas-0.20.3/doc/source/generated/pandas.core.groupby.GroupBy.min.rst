pandas\.core\.groupby\.GroupBy\.min
===================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.min