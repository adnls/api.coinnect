pandas\.core\.resample\.Resampler\.prod
=======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.prod