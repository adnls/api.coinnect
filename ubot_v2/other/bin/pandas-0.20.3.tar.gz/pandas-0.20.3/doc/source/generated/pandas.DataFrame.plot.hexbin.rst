pandas.DataFrame.plot.hexbin
============================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.hexbin