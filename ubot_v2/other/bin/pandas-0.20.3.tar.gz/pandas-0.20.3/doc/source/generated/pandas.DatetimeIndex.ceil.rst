pandas\.DatetimeIndex\.ceil
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.ceil