pandas\.core\.groupby\.DataFrameGroupBy\.fillna
===============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.fillna