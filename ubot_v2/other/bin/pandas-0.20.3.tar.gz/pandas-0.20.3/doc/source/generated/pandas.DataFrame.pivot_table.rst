pandas\.DataFrame\.pivot\_table
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.pivot_table