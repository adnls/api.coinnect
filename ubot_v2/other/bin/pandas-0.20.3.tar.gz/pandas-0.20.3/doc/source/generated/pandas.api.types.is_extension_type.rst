pandas\.api\.types\.is\_extension\_type
=======================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_extension_type