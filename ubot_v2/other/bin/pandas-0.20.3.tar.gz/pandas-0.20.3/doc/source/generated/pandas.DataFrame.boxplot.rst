pandas\.DataFrame\.boxplot
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.boxplot