pandas\.core\.groupby\.GroupBy\.size
====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.size