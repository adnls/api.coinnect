pandas\.core\.groupby\.GroupBy\.\_\_iter\_\_
============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.__iter__