pandas\.DataFrame\.update
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.update