pandas\.core\.window\.Expanding\.max
====================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.max