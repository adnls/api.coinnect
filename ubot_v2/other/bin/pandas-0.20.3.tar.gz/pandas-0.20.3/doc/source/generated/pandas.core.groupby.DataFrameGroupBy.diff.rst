pandas\.core\.groupby\.DataFrameGroupBy\.diff
=============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.diff