pandas\.api\.types\.is\_signed\_integer\_dtype
==============================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_signed_integer_dtype