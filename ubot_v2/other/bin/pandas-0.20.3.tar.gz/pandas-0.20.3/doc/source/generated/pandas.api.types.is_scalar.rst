pandas\.api\.types\.is\_scalar
==============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_scalar