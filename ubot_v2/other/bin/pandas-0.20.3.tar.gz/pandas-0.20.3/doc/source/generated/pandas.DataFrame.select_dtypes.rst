pandas\.DataFrame\.select\_dtypes
=================================

.. currentmodule:: pandas

.. automethod:: DataFrame.select_dtypes