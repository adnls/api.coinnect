pandas\.api\.types\.is\_period\_dtype
=====================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_period_dtype