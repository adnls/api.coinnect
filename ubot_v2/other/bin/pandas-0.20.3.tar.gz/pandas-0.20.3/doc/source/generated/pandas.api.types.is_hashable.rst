pandas\.api\.types\.is\_hashable
================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_hashable