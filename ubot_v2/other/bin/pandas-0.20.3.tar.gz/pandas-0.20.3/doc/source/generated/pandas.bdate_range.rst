pandas\.bdate\_range
====================

.. currentmodule:: pandas

.. autofunction:: bdate_range