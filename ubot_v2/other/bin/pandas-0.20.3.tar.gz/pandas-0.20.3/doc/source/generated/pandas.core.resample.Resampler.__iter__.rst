pandas\.core\.resample\.Resampler\.\_\_iter\_\_
===============================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.__iter__