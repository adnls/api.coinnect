pandas\.api\.types\.is\_number
==============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_number