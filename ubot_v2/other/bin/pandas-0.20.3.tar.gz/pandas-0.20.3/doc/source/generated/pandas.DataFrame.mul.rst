pandas\.DataFrame\.mul
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.mul