pandas\.DataFrame\.tshift
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.tshift