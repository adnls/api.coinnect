pandas\.DatetimeIndex\.asi8
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.asi8