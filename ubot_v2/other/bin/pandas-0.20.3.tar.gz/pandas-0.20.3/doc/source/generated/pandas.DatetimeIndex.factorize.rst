pandas\.DatetimeIndex\.factorize
================================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.factorize