pandas\.api\.types\.is\_interval\_dtype
=======================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_interval_dtype