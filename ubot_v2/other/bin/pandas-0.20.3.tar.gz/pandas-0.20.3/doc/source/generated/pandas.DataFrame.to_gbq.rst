pandas\.DataFrame\.to\_gbq
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_gbq