pandas\.CategoricalIndex\.rename\_categories
============================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.rename_categories