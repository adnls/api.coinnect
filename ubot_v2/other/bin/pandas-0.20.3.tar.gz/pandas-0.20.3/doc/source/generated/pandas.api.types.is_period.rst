pandas\.api\.types\.is\_period
==============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_period