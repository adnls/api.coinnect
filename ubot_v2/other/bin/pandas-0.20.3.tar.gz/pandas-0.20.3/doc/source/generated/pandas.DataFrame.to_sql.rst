pandas\.DataFrame\.to\_sql
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_sql