pandas\.DataFrame\.sort\_index
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.sort_index