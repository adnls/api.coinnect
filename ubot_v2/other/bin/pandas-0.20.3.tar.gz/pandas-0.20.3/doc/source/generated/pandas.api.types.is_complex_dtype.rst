pandas\.api\.types\.is\_complex\_dtype
======================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_complex_dtype