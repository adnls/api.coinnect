pandas\.DataFrame\.swapaxes
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.swapaxes