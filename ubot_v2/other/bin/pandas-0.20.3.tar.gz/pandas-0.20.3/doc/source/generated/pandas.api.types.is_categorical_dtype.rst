pandas\.api\.types\.is\_categorical\_dtype
==========================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_categorical_dtype