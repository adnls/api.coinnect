pandas\.DataFrame\.to\_dict
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_dict