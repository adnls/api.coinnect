pandas\.DataFrame\.to\_html
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_html