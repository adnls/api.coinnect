pandas\.DataFrame\.as\_blocks
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.as_blocks