pandas\.DataFrame\.le
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.le