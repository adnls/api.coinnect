pandas\.CategoricalIndex\.as\_ordered
=====================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.as_ordered