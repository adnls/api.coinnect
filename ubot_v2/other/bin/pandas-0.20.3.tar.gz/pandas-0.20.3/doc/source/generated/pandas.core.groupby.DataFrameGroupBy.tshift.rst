pandas\.core\.groupby\.DataFrameGroupBy\.tshift
===============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.tshift