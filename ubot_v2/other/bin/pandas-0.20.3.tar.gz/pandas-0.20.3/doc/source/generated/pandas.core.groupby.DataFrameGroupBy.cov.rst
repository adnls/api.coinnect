pandas\.core\.groupby\.DataFrameGroupBy\.cov
============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.cov