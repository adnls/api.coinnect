pandas\.DatetimeIndex\.dropna
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.dropna