pandas\.api\.types\.is\_integer\_dtype
======================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_integer_dtype