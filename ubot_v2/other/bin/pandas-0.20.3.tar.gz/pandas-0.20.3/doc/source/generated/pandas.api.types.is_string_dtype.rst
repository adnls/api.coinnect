pandas\.api\.types\.is\_string\_dtype
=====================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_string_dtype