pandas\.DatetimeIndex\.dtype\_str
=================================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.dtype_str