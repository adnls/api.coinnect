pandas.Categorical
==================

.. currentmodule:: pandas

.. autoclass:: Categorical