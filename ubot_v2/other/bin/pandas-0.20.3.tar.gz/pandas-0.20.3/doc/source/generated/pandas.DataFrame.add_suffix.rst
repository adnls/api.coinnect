pandas\.DataFrame\.add\_suffix
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.add_suffix