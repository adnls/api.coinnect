pandas\.DataFrame\.truediv
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.truediv