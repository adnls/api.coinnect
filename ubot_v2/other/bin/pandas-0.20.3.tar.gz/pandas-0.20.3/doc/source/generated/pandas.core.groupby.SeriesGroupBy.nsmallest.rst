pandas\.core\.groupby\.SeriesGroupBy\.nsmallest
===============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: SeriesGroupBy.nsmallest