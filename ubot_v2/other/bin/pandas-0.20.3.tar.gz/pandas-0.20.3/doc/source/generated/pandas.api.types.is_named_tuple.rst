pandas\.api\.types\.is\_named\_tuple
====================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_named_tuple