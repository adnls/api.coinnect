pandas\.DataFrame\.set\_index
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.set_index