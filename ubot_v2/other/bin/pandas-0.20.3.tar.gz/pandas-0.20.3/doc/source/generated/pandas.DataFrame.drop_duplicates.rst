pandas\.DataFrame\.drop\_duplicates
===================================

.. currentmodule:: pandas

.. automethod:: DataFrame.drop_duplicates