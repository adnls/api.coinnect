pandas\.core\.resample\.Resampler\.backfill
===========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.backfill