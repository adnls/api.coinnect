pandas\.core\.window\.Expanding\.std
====================================

.. currentmodule:: pandas.core.window

.. automethod:: Expanding.std