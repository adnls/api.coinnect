pandas\.core\.groupby\.SeriesGroupBy\.unique
============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: SeriesGroupBy.unique