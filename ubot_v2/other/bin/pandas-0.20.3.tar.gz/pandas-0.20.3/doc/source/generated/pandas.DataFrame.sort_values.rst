pandas\.DataFrame\.sort\_values
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.sort_values