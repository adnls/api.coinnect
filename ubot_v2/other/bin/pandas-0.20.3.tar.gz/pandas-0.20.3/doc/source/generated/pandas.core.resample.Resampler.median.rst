pandas\.core\.resample\.Resampler\.median
=========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.median