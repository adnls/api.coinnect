pandas\.CategoricalIndex\.remove\_unused\_categories
====================================================

.. currentmodule:: pandas

.. automethod:: CategoricalIndex.remove_unused_categories