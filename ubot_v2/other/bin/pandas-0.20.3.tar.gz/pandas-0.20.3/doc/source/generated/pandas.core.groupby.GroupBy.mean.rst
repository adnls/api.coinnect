pandas\.core\.groupby\.GroupBy\.mean
====================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.mean