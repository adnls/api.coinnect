pandas\.core\.groupby\.DataFrameGroupBy\.skew
=============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.skew