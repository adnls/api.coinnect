pandas\.DatetimeIndex\.fillna
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.fillna