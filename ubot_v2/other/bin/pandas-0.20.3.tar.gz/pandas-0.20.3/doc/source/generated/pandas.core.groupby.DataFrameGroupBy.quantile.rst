pandas\.core\.groupby\.DataFrameGroupBy\.quantile
=================================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.quantile