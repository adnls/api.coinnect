pandas\.DataFrame\.transform
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.transform