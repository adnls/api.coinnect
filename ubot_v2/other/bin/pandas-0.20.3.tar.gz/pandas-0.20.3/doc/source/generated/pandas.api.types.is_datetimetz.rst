pandas\.api\.types\.is\_datetimetz
==================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_datetimetz