pandas\.DataFrame\.astype
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.astype