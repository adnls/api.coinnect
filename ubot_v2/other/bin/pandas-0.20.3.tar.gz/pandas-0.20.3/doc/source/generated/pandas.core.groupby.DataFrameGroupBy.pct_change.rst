pandas\.core\.groupby\.DataFrameGroupBy\.pct\_change
====================================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.pct_change