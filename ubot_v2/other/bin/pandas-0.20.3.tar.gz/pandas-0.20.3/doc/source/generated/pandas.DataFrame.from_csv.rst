pandas\.DataFrame\.from\_csv
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_csv