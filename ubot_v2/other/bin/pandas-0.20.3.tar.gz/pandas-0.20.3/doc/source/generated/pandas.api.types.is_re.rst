pandas\.api\.types\.is\_re
==========================

.. currentmodule:: pandas.api.types

.. autofunction:: is_re