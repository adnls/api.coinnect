pandas\.DatetimeIndex\.argmax
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.argmax