pandas\.DataFrame\.eval
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.eval