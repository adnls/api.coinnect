pandas\.DataFrame\.reindex\_axis
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.reindex_axis