pandas\.core\.resample\.Resampler\.ffill
========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.ffill