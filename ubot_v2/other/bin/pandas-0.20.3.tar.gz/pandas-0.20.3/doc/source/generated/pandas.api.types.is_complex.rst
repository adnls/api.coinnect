pandas\.api\.types\.is\_complex
===============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_complex