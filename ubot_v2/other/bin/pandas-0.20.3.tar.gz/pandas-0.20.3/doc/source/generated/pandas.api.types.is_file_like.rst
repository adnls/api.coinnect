pandas\.api\.types\.is\_file\_like
==================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_file_like