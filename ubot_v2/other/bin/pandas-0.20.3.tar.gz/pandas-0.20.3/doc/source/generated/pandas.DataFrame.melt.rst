pandas\.DataFrame\.melt
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.melt