pandas\.core\.resample\.Resampler\.fillna
=========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.fillna