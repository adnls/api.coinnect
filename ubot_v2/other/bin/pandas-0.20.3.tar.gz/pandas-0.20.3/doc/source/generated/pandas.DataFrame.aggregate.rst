pandas\.DataFrame\.aggregate
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.aggregate