pandas\.DataFrame\.reindex\_like
================================

.. currentmodule:: pandas

.. automethod:: DataFrame.reindex_like