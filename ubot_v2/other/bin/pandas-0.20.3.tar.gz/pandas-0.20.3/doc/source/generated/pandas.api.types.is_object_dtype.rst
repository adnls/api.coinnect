pandas\.api\.types\.is\_object\_dtype
=====================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_object_dtype