pandas\.DataFrame\.from\_items
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.from_items