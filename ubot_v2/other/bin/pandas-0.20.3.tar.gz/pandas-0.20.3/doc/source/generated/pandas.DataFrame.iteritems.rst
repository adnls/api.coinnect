pandas\.DataFrame\.iteritems
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.iteritems