pandas\.DataFrame\.rename\_axis
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.rename_axis