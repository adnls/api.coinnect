pandas\.core\.resample\.Resampler\.size
=======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.size