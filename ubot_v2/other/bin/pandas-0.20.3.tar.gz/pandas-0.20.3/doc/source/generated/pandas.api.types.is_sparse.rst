pandas\.api\.types\.is\_sparse
==============================

.. currentmodule:: pandas.api.types

.. autofunction:: is_sparse