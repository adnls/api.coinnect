pandas\.core\.groupby\.GroupBy\.max
===================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.max