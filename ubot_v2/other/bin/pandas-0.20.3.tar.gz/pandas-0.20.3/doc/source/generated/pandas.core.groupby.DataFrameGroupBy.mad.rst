pandas\.core\.groupby\.DataFrameGroupBy\.mad
============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.mad