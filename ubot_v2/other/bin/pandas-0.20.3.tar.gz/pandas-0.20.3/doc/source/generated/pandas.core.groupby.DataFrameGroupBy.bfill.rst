pandas\.core\.groupby\.DataFrameGroupBy\.bfill
==============================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.bfill