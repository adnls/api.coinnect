pandas\.DatetimeIndex\.freqstr
==============================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.freqstr