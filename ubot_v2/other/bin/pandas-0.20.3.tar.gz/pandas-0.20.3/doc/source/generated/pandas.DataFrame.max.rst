pandas\.DataFrame\.max
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.max