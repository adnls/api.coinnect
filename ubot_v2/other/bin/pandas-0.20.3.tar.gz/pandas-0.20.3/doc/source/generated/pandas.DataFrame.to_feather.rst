pandas\.DataFrame\.to\_feather
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_feather