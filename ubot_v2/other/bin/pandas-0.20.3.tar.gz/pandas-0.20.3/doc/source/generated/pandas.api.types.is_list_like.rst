pandas\.api\.types\.is\_list\_like
==================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_list_like