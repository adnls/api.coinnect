pandas.CategoricalIndex
=======================

.. currentmodule:: pandas

.. autoclass:: CategoricalIndex