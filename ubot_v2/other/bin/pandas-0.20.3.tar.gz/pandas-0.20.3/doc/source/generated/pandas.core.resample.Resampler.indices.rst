pandas\.core\.resample\.Resampler\.indices
==========================================

.. currentmodule:: pandas.core.resample

.. autoattribute:: Resampler.indices