pandas\.api\.types\.is\_int64\_dtype
====================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_int64_dtype