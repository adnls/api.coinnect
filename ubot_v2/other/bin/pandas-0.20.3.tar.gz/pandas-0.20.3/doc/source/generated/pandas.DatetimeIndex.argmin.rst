pandas\.DatetimeIndex\.argmin
=============================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.argmin