pandas\.DataFrame\.reorder\_levels
==================================

.. currentmodule:: pandas

.. automethod:: DataFrame.reorder_levels