pandas\.api\.types\.is\_float\_dtype
====================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_float_dtype