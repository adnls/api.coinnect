pandas\.DataFrame\.is\_copy
===========================

.. currentmodule:: pandas

.. autoattribute:: DataFrame.is_copy