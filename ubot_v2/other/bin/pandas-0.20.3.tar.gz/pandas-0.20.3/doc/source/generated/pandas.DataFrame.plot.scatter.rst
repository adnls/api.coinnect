pandas.DataFrame.plot.scatter
=============================

.. currentmodule:: pandas

.. autoaccessormethod:: DataFrame.plot.scatter