pandas\.DataFrame\.lt
=====================

.. currentmodule:: pandas

.. automethod:: DataFrame.lt