pandas\.core\.resample\.Resampler\.transform
============================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.transform