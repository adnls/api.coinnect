pandas\.DataFrame\.to\_json
===========================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_json