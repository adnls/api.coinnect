pandas\.core\.groupby\.DataFrameGroupBy\.describe
=================================================

.. currentmodule:: pandas.core.groupby

.. automethod:: DataFrameGroupBy.describe