pandas\.DatetimeIndex\.date
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.date