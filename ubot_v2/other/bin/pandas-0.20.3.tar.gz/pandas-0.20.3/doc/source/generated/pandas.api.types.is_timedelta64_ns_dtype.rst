pandas\.api\.types\.is\_timedelta64\_ns\_dtype
==============================================

.. currentmodule:: pandas.api.types

.. autofunction:: is_timedelta64_ns_dtype