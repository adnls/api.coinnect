pandas\.DataFrame\.to\_period
=============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_period