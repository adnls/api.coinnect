pandas\.core\.groupby\.DataFrameGroupBy\.plot
=============================================

.. currentmodule:: pandas.core.groupby

.. autoattribute:: DataFrameGroupBy.plot