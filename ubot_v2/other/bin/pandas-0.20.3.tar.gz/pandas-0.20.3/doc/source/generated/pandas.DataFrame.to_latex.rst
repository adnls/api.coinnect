pandas\.DataFrame\.to\_latex
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_latex