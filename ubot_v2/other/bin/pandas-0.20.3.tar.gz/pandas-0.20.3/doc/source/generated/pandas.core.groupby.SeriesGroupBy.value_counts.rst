pandas\.core\.groupby\.SeriesGroupBy\.value\_counts
===================================================

.. currentmodule:: pandas.core.groupby

.. automethod:: SeriesGroupBy.value_counts