pandas\.DataFrame\.prod
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.prod