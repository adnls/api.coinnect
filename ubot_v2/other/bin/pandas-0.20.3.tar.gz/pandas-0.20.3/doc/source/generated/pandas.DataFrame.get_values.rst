pandas\.DataFrame\.get\_values
==============================

.. currentmodule:: pandas

.. automethod:: DataFrame.get_values