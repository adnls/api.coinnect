pandas\.core\.resample\.Resampler\.count
========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.count