pandas\.DataFrame\.reset\_index
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.reset_index