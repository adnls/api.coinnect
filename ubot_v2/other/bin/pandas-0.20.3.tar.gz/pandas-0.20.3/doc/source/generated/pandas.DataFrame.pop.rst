pandas\.DataFrame\.pop
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.pop