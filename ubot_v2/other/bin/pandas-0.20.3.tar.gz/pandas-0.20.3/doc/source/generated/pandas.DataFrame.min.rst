pandas\.DataFrame\.min
======================

.. currentmodule:: pandas

.. automethod:: DataFrame.min