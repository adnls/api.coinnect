pandas\.DataFrame\.lookup
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.lookup