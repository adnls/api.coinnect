pandas\.DataFrame\.tz\_localize
===============================

.. currentmodule:: pandas

.. automethod:: DataFrame.tz_localize