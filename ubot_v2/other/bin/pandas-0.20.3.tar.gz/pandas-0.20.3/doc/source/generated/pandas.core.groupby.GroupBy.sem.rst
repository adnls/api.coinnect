pandas\.core\.groupby\.GroupBy\.sem
===================================

.. currentmodule:: pandas.core.groupby

.. automethod:: GroupBy.sem