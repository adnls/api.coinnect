pandas\.DataFrame\.divide
=========================

.. currentmodule:: pandas

.. automethod:: DataFrame.divide