pandas\.core\.resample\.Resampler\.bfill
========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.bfill