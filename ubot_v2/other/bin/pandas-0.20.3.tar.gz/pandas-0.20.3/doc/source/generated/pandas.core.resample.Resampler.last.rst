pandas\.core\.resample\.Resampler\.last
=======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.last