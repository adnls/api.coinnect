pandas\.DataFrame\.to\_dense
============================

.. currentmodule:: pandas

.. automethod:: DataFrame.to_dense