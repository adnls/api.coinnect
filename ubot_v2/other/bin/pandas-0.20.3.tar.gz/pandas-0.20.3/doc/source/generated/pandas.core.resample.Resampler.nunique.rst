pandas\.core\.resample\.Resampler\.nunique
==========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.nunique