pandas\.DatetimeIndex\.freq
===========================

.. currentmodule:: pandas

.. autoattribute:: DatetimeIndex.freq