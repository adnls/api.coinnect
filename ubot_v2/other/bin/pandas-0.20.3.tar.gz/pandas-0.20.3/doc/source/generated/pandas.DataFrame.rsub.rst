pandas\.DataFrame\.rsub
=======================

.. currentmodule:: pandas

.. automethod:: DataFrame.rsub