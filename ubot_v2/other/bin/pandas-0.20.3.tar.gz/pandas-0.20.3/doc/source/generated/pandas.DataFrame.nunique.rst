pandas\.DataFrame\.nunique
==========================

.. currentmodule:: pandas

.. automethod:: DataFrame.nunique