pandas\.DatetimeIndex\.drop
===========================

.. currentmodule:: pandas

.. automethod:: DatetimeIndex.drop