pandas\.core\.resample\.Resampler\.asfreq
=========================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.asfreq