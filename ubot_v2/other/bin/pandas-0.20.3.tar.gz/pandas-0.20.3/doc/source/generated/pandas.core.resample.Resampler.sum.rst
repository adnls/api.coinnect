pandas\.core\.resample\.Resampler\.sum
======================================

.. currentmodule:: pandas.core.resample

.. automethod:: Resampler.sum