pandas\.core\.window\.EWM\.corr
===============================

.. currentmodule:: pandas.core.window

.. automethod:: EWM.corr